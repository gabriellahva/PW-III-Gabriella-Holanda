<?php

$n1 = 15;
$n2 = 8;

echo "Antes da troca: \n";
echo "Número 1: " . $n1 . "\n";
echo "Número 2: " . $n2 . "\n";


echo "Após a troca: \n";
echo "Número 1: " , $n2 , "\n";
echo "Número 2: " , $n1 , "\n";

?>
