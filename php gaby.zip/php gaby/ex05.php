<?php

$n1 = 15;
$n2 = 8;

echo "Antes da troca: <br>";
echo "Número 1: " . $n1 . "<br>";
echo "Número 2: " . $n2 . "<br> <br>";


echo "Após a troca: <br>";
echo "Número 1: " , $n2 , "<br>";
echo "Número 2: " , $n1 , "<br>";

?>
