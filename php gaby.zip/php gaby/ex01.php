<?php

$n1 = 15;
$n2 = 55;

$soma = $n1 + $n2;
$sub = $n1 - $n2;
$mult = $n1 * $n2;
$div = $n1 / $n2;

echo "A soma é: " ,$soma, "</p>";
echo "A subtração é: " ,$sub, "</p>";
echo "A multiplicação é: " ,$mult, "</p>";
echo "A divisão é: " ,$div, "</p>";

?>