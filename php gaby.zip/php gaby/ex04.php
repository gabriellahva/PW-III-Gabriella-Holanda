<?php

$base = 15;
$altura = 5;

$area = $base * $altura;

echo "A área do retângulo é: " ,$area," m2\n";

?>
