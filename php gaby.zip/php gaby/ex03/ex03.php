<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome_vendedor = $_POST['nome'];
    $salario_fixo = floatval($_POST['salario_fixo']);
    $total_vendas = floatval($_POST['total_vendas']);

    $comissao = $total_vendas * 0.15;

    $salario_final = $salario_fixo + $comissao;

    echo "<h3>Resumo do Salário do Vendedor</h3>";
    echo "<p><strong>Nome:</strong> " ,$nome_vendedor, "</p>";
    echo "<p><strong>Salário Fixo:</strong> R$ " ,$salario_fixo, "</p>";
    echo "<p><strong>Comissão (15% sobre vendas):</strong> R$ " ,$comissao,  "</p>";
    echo "<p><strong>Salário Final:</strong> R$ " ,$salario_final, "</p>";
}
?>