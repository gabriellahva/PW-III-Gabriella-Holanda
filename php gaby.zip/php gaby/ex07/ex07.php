<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $valor = intval($_POST['valor']);

    $antecessor = $valor - 1;

    echo "<h3>Resultado</h3>";
    echo "<p>O antecessor de $valor é $antecessor.</p>";
}
?>