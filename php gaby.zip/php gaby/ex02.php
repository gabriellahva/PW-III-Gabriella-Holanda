<?php

$distancia = 500;
$comb_gasto = 60;

$consumomedio = $distancia / $comb_gasto;

echo "O consumo médio do automóvel é: " ,$consumomedio, "\n";

?>