<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $consumo_carro = floatval($_POST['consumo_carro']);
    $distancia = floatval($_POST['distancia']);
    $preco_litro = floatval($_POST['preco_litro']);


    $litros = $distancia / $consumo_carro;

    $custo_total = $litros * $preco_litro;

    echo "<h3>Custo Estimado com Combustível</h3>";
    echo "<p><strong>Distância:</strong> " ,$distancia, " km</p>";
    echo "<p><strong>Consumo do Carro:</strong> " ,$consumo_carro, " Km/l</p>";
    echo "<p><strong>Preço do Litro:</strong> R$ " ,$preco_litro, "</p>";
    echo "<p><strong>Custo Estimado:</strong> R$ " ,$custo_total, "</p>";
}
?>